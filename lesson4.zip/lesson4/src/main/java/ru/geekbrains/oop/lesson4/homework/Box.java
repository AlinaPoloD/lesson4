package ru.geekbrains.oop.lesson4.homework;

import java.util.ArrayList;

public class Box <T extends Fruit>{

    private ArrayList<T> arrayList;

}
