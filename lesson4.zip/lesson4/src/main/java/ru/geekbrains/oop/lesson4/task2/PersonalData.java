package ru.geekbrains.oop.lesson4.task2;

public interface PersonalData {

    String getInn();

}
