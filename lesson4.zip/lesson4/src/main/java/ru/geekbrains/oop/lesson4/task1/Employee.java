package ru.geekbrains.oop.lesson4.task1;

public class Employee {

    private String name;

    public String getName() {
        return name;
    }

    public Employee(String name) {
        this.name = name;
    }
}
