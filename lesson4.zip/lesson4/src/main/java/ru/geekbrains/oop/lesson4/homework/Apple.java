package ru.geekbrains.oop.lesson4.homework;

public class Apple extends Fruit{

    public Apple(){
        super(1f);
    }

}
